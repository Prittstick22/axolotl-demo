"""Dependency-free named constants for the chess game."""


class Enum:
    def __new__(cls, value):
        for member in cls.__dict__.values():
            if isinstance(member, cls) and member.value == value:
                return member
        raise ValueError(f'{value!r} is not a valid {cls.__name__}')

    @classmethod
    def _member(cls, name, value):
        member = object.__new__(cls)
        member.name = name
        member.value = value
        return member

    def __repr__(self):
        return f'{type(self).__name__}.{self.name}'
